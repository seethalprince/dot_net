﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
namespace onlinecourt
{
    public partial class Adminlogin : System.Web.UI.Page
    {
         SqlConnection cnn = new SqlConnection(@"Data Source=DELL-PC\SQLEXPRESS;Initial Catalog=Ecourtservices;User ID=sa;Password=seethal;Pooling=False");

         SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            cnn.Open();
            cmd.Connection = cnn;
                
            if ((TextBox1.Text == "admin") && (TextBox2.Text == "123"))
                
            {



                Response.Redirect("Admin/Addjudge.aspx");
            }
            else{
              ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Upload Image", "alert('Invalid Username And Password')", true);}
        }
    }
    }
