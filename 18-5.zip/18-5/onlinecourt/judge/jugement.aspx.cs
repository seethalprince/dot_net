﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace onlinecourt.judge
{
    public partial class jugement : System.Web.UI.Page
    {
        SqlConnection cnn = new SqlConnection(@"Data Source=DELL-PC\SQLEXPRESS;Initial Catalog=Ecourtservices;User ID=sa;Password=seethal;Pooling=False");

        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            string jugement = "";
            jugement = txtjudgement.Text;
            cnn.Open();
            cmd.Connection = cnn;
            cmd.CommandText = "insert into judement (judgement) values('" +  jugement + "')";
            cmd.ExecuteNonQuery();
            cnn.Close();



            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alert message", "alert('judge added successfully!!!!!!!!!!!!')", true);

        }
    }
}