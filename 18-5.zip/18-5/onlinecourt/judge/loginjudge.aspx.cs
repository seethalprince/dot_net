﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace onlinecourt.judge
{
    public partial class loginjudge : System.Web.UI.Page
    {
        SqlConnection cnn = new SqlConnection(@"Data Source=DELL-PC\SQLEXPRESS;Initial Catalog=Ecourtservices;User ID=sa;Password=seethal;Pooling=False");

        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
             string name = "";
            name = TextBox1.Text;
            string barno = "";
            barno = TextBox2.Text;

            cnn.Open();
            cmd.Connection = cnn;
            cmd.CommandText = "select count(*) from judgeregister where name='" + name + "' and phone='" + barno + "'";
            int count = Convert.ToInt32(cmd.ExecuteScalar());
            cnn.Close();
            if (count == 0)
            {
                Response.Write("<script>alert('PLEASE CHECK YOUR USERNAME AND BAR COUNCIL NO....')</script>");
            }
            else
            {
                Session["name"] = name;
                cnn.Open();
                cmd.Connection = cnn;
                cmd.CommandText = "select id from judgeregister where name='" + name + "' and phone='" + barno + "'";
                int id = Convert.ToInt32(cmd.ExecuteScalar());
                cnn.Close();
                Session["id"] = id;
                Response.Redirect("view.aspx");
            }

           
        }
        }

        
    
}
