﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
namespace onlinecourt.User
{
    public partial class Cnrsearch : System.Web.UI.Page
    {
        SqlConnection cnn;
        SqlCommand cmd;
        SqlDataAdapter ad;
        DataSet dt;
        protected void Page_Load(object sender, EventArgs e)
        {
            cnn = new SqlConnection(@"Data Source=DELL-PC\SQLEXPRESS;Initial Catalog=Ecourtservices;User ID=sa;Password=seethal;Pooling=False");
            cnn.Open();


        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string cnr = "";
            cnr = TextBox2.Text;
            //cnn.Open();
            //cmd.Connection = cnn;
            //cmd.CommandText = "select * from  casedetails where case_no='" + cnr + "' or Adv_name='" + cnr + "'or firno='" + cnr + "'";
            //cnn.Close();


            cmd = new SqlCommand("select * from casedetails where case_no in(select case_no from cnrdetails where cnrnumber='"+cnr+"')", cnn);
            ad = new SqlDataAdapter(cmd);
            ad.SelectCommand = cmd;
            dt = new DataSet();
            ad.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();

        }



     
       


    }
}