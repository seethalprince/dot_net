﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


namespace onlinecourt.Admin
{
    public partial class Courtorderregister : System.Web.UI.Page
    {
        SqlConnection cnn = new SqlConnection(@"Data Source=DELL-PC\SQLEXPRESS;Initial Catalog=Ecourtservices;User ID=sa;Password=seethal;Pooling=False");

        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            txtadv.Text = "";
            txtcasetype.Text = "";
            txtcno.Text = "";
            txtcourtno.Text="";
            txtdate.Text = "";
            txtjudg.Text = "";
            txtparty.Text = "";


        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string courtno = "";
            courtno = txtcourtno.Text;
            string judge = "";
            judge = txtjudg.Text;
            string issue = "";
            issue = txtdate.Text;
            string cno="";
            cno=txtcno.Text;
            string casetype="";
            casetype=txtcasetype.Text;
            string party="";
            party=txtparty.Text;
            string advname="";
            advname=txtadv.Text;
            cnn.Open();
            cmd.Connection = cnn;
            cmd.CommandText = "insert into courtorder(cno,judge_name,issue_date,case_no,case_type,party_name,adv_name) values('" + courtno + "','" + judge + "','" + issue + "','"+cno+"','"+casetype+"','"+party+"','"+advname+"')";
            cmd.ExecuteNonQuery();
            cnn.Close();
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alert message", "alert('courtorder added successfully')", true);
            

        }

       
    }
}