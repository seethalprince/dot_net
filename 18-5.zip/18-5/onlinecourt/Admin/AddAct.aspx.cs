﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
namespace onlinecourt.Admin
{
    public partial class AddAct : System.Web.UI.Page
    {
        SqlConnection cnn = new SqlConnection(@"Data Source=DELL-PC\SQLEXPRESS;Initial Catalog=Ecourtservices;User ID=sa;Password=seethal;Pooling=False");

        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
           
            txtno.Text = "";
            txtremark.Text = "";
            txttpe.Text = "";

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string actno = "";
            actno = txtno.Text;
            string atype = "";
            atype = txttpe.Text;
            string remark = "";
            remark = txtremark.Text;
            cnn.Open();
            cmd.Connection = cnn;
            cmd.CommandText = "insert into act_register(act_no,act_type,remark) values('" + actno + "','" +atype+ "','" + remark+ "')";
                cmd.ExecuteNonQuery();
              cnn.Close();



            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alert message", "alert('judge added successfully!!!!!!!!!!!!')", true);


            

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}