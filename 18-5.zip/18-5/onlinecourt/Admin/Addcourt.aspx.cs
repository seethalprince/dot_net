﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
namespace onlinecourt.Admin
{
    public partial class Addcourt : System.Web.UI.Page
    {
        SqlConnection cnn=new SqlConnection(@"Data Source=DELL-PC\SQLEXPRESS;Initial Catalog=Ecourtservices;User ID=sa;Password=seethal;Pooling=False");

        SqlCommand cmd=new SqlCommand();

        protected void Page_Load(object sender, EventArgs e)
        {
           
            


        }

        protected void BTNRESET_Click(object sender, EventArgs e)
        {
           
            txtcjudge.Text="";
            txtcno.Text="";
            txtcourtaddre.Text="";
            txtctpe.Text="";
            txtname.Text="";
}

        protected void BTNSAVE_Click(object sender, EventArgs e)
        {
             string courtname = "";

          courtname=  txtname.Text;
            string judge="";
            judge=txtcjudge.Text;
            string courtno ="";
            courtno=  txtcno.Text;
            string courttype="";
            courttype= txtctpe.Text;
            string courtaddress="";
            courtaddress= txtcourtaddre.Text;
            cnn.Open();
            cmd.Connection=cnn;

            cmd.CommandText = "insert into courtregister(c_name,judge,court_no,court_type,c_address)values('" + courtname + "','" + judge + "','" + courtno + "','" + courttype + "','" + courtname + "')";
            cmd.ExecuteNonQuery();

            cnn.Close();

            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alert message", "alert('court added successfully')", true);
            
        }
    }
}