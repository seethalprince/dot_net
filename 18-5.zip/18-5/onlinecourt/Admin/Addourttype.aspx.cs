﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
namespace onlinecourt.Admin
{
    public partial class Addourttype : System.Web.UI.Page
    {
        SqlConnection cnn = new SqlConnection(@"Data Source=DELL-PC\SQLEXPRESS;Initial Catalog=Ecourtservices;User ID=sa;Password=seethal;Pooling=False");

        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string cno = "";
            cno=txtcno.Text;
            string ctype="";
            ctype=txtctype.Text;
            string remark="";
            remark=txtremark.Text;
              cnn.Open();
            cmd.Connection = cnn;
            cmd.CommandText = "insert into CourtType(cno,ctype,remark) values('" + cno + "','" +ctype+ "','" + remark+ "')";
                cmd.ExecuteNonQuery();
              cnn.Close();



            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alert message", "alert('court type added successfully!!!!!!!!!!!!')", true);

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            txtcno.Text = "";
            txtctype.Text = "";
            txtremark.Text = "";

        }
    }
}