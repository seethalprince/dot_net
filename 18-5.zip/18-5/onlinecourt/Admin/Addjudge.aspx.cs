﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
namespace onlinecourt.Admin
{
    public partial class Addjudge : System.Web.UI.Page
    {
        SqlConnection cnn = new SqlConnection(@"Data Source=DELL-PC\SQLEXPRESS;Initial Catalog=Ecourtservices;User ID=sa;Password=seethal;Pooling=False");

        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string name = "";
            name = txtname.Text;
            string reg = "";

            reg = txtreg.Text;
            string dob = "";
            dob = txtdob.Text;
            string sex = "";
            sex = drpsex.SelectedItem.Text;
            string ph = "";

            ph = txtph.Text;
            string offadd = "";
            offadd = txtoff.Text;
            string resadd = "";
            resadd = txtres.Text;
            string city = txtci.Text;
            city = txtci.Text;
            string district = "";
            district = txtdistrict.Text;
            string quali = "";
            quali = txtquali.Text;
            string specify = "";
            specify = txtspeci.Text;
            string hist = "";

            hist = txthistory.Text;
            string cno = "";
            cno = txtcourtno.Text;
            string cadd = "";
            cadd = txtcaddress.Text;
            string imgpath = "";
            imgpath = Image1.ImageUrl;
            cnn.Open();
            cmd.Connection = cnn;
            cmd.CommandText = "insert into judgeregister(name,reg_date,sex,dob,phone,off_address,res_address,city,district,qualification,specify,history,image,court_no,court_address) values('" + name + "','" + reg + "','" + sex + "','"+dob+"','"+ph+"','"+offadd+"','"+resadd+"','"+city+"','"+district+"','"+quali+"','"+specify+"','"+hist+"','"+imgpath+"','"+cno+"','"+cadd+"')";
            cmd.ExecuteNonQuery();
            cnn.Close();

            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alert message", "alert('judge added successfully')", true);


        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            txtcaddress.Text = "";
            txtci.Text = "";
            txtcourtno.Text = "";
            txtdistrict.Text = "";
            txtdob.Text = "";
            txthistory.Text = "";
            txtname.Text = "";
            txtoff.Text = "";
            txtph.Text = "";
            txtquali.Text = "";
            txtreg.Text = "";
            txtres.Text = "";
            txtspeci.Text = "";
            drpsex.Text = "";


        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            string filename = FileUpload1.FileName;
            string filepath = Server.MapPath("~/file/");
            FileUpload1.SaveAs(filepath + filename);
            Image1.ImageUrl = "~/file/" + filename;
            //Session["img"] = FileUpload1.FileName;
            //FileUpload1.SaveAs(Server.MapPath("./images/" + FileUpload1.FileName));
            //Image1.ImageUrl = "./images/" + FileUpload1.FileName;
            //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Upload Image", "alert('Image Loaded Successfully')", true);
        }
    }
}