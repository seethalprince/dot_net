﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace onlinecourt.Admin
{
    public partial class Addcaseregister : System.Web.UI.Page
    {
        SqlConnection cnn = new SqlConnection(@"Data Source=DELL-PC\SQLEXPRESS;Initial Catalog=Ecourtservices;User ID=sa;Password=seethal;Pooling=False");

        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string caseno = "";
            caseno= Txtcno.Text;
            string casename = "";
            casename = txtcname.Text;
            string ctype = "";
            ctype = txtctype.Text;
            string reg = "";
            reg = txtregi.Text;
            string police = "";
            police = txtpolice.Text;
            string adv = "";
            adv = DropDownList1.SelectedItem.Text;
            string firno = "";
            firno = txtfir.Text;
            string respond = "";
            respond = txtrespo.Text;
            string courtname = "";
            courtname = txtcourtname.Text;
            string casestatus = "";
            casestatus = txtcasestatus.Text;
            cnn.Open();
            cmd.Connection = cnn;
            cmd.CommandText = "insert into casedetails(case_no,c_name,c_type,reg_year,policestation,Adv_name,firno,respond,court_name,case_status) values('" + caseno + "','" + caseno + "','" + ctype + "','"+reg+"','"+police+"','"+adv+"','"+firno+"','"+respond+"','"+courtname+"','"+casestatus+"')";
            cmd.ExecuteNonQuery();

            Session["police"] = police;
            Session["Fno"] = firno;
            Session["reg"] = reg;
            cnn.Close();

            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alert message", "alert('Case added successfully!!!!!!!!!!!!')", true);






        }

       

        protected void Button2_Click(object sender, EventArgs e)
        {
            txtadv.Text = "";
            txtcasestatus.Text = "";
            txtcname.Text = "";
            Txtcno.Text = "";
            txtcourtname.Text = "";
            txtctype.Text = "";
            txtfir.Text = "";
            txtpolice.Text = "";
            txtrespo.Text = "";
            Txtcno.Text = "";
            txtregi.Text = "";

        }
    }
}