﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
namespace onlinecourt.Admin
{
    public partial class Addadvocate : System.Web.UI.Page
    {
        SqlConnection cnn = new SqlConnection(@"Data Source=DELL-PC\SQLEXPRESS;Initial Catalog=Ecourtservices;User ID=sa;Password=seethal;Pooling=False");

        SqlCommand cmd = new SqlCommand();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            txtbardetail.Text = "";
            txtbarno.Text = "";
            txtcity.Text = "";
            txtdob.Text = "";
            txtfrom.Text = "";
            txthistory.Text = ""; 
            
            txtname.Text = "";
            txtoff.Text = "";
            txtregdate.Text = "";
            txtres.Text = "";
            txtspecify.Text = "";
            txtstate.Text = "";
            txtto.Text = "";
            txtfrom.Text = "";
            drpsex.Text = "";



                
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string aname = "";
            aname = txtname.Text;
            string reg = "";
            reg = txtregdate.Text;
            string barno = "";
            barno = txtbarno.Text;
            string bardetails = "";
            bardetails = txtbardetail.Text;
            string sex = "";
            sex = drpsex.SelectedItem.Text;
            string dob = "";
            dob = txtdob.Text;
            string ph = "";
            ph = txtph.Text;
            string offadd = "";
            offadd = txtoff.Text;
            string resadd = "";
            resadd = txtres.Text;
            string city = "";
            city = txtcity.Text;
            string district = "";
            district = txtdis.Text;
            string qualif = "";
            qualif= txtqualif.Text;
            string specify = "";
            specify = txtspecify.Text;
            string history = "";
            history = txthistory.Text;
            string state = "";
            state = txtstate.Text;
            string from = "";
           from= txtfrom.Text;

           string totime = "";
           totime = txtto.Text;
           string imgpath = "";
           imgpath = Image1.ImageUrl;
           cnn.Open();
           cmd.Connection = cnn;
           cmd.CommandText = "insert into Advocateregister (name,reg_date,bar_no,bar_details,sex,dob,phone,off_address,res_address,city,district,quaification,specify,history,state_code,time_from,time_to,photo) values ('" + aname + "','" + reg + "','" + barno + "','" + bardetails + "','" + sex + "','" + dob + "','" + ph + "','" + offadd + "','" + resadd + "','" + city + "','" + district + "','" + qualif + "','" + specify + "','" + history + "','" + state + "','" + from + "','" + totime +"','" + imgpath+"')";
           cmd.ExecuteNonQuery();

           cnn.Close();

           ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alert message", "alert('Addvocate added successfully')", true);
            

        }

        protected void Button3_Click(object sender, EventArgs e)
        {

            string filename = FileUpload1.FileName;
            string filepath = Server.MapPath("~/file/");
            FileUpload1.SaveAs(filepath + filename);
            Image1.ImageUrl = "~/file/" + filename;
                //Session["img"] = FileUpload1.FileName;
                //FileUpload1.SaveAs(Server.MapPath("./images/" + FileUpload1.FileName));
                //Image1.ImageUrl = "./images/" + FileUpload1.FileName;
                //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Upload Image", "alert('Image Loaded Successfully')", true);
        }
    }
}