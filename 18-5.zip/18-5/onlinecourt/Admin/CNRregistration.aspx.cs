﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace onlinecourt.Admin
{
    public partial class CNRregistration : System.Web.UI.Page
    {
        SqlConnection cnn = new SqlConnection(@"Data Source=DELL-PC\SQLEXPRESS;Initial Catalog=Ecourtservices;User ID=sa;Password=seethal;Pooling=False");

        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string caseno = "";
            caseno = DropDownList1.Text;
            string cnr = "";
            cnr = TextBox2.Text;
            cnn.Open();
            cmd.Connection = cnn;
            cmd.CommandText = "insert into cnrdetails(case_no,cnrnumber) values('" + caseno + "','" + cnr + "')";
            cmd.ExecuteNonQuery();
            cnn.Close();



            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alert message", "alert('CNR added successfully!!!!!!!!!!!!')", true);

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox2.Text = "";
            DropDownList1.SelectedItem.Text = "";
        }
    }
}