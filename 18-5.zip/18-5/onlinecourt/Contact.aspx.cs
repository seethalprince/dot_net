﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace onlinecourt
{
    public partial class Contact : System.Web.UI.Page
    {
        SqlConnection cnn = new SqlConnection(@"Data Source=DELL-PC\SQLEXPRESS;Initial Catalog=Ecourtservices;User ID=sa;Password=seethal;Pooling=False");

        SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string lname = "";
            lname = TextBox4.Text;
            string fname = "";
            fname = TextBox1.Text;
            string email = "";
            email = TextBox2.Text;
            string msg = "";
            msg = TextBox3.Text;
            cnn.Open();
            cmd.Connection = cnn;
            cmd.CommandText = "insert into feed(fname,lname,email,message) values('" + fname + "','" + lname + "','" + email + "','" + msg + "')";
            cmd.ExecuteNonQuery();
            cnn.Close();
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alert message", "alert('message send successfully!!!!!!!!!!!!')", true);
        }
    }
}

        
