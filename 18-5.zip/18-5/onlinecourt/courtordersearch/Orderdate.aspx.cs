﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace onlinecourt.courtordersearch
{
    public partial class Orderdate : System.Web.UI.Page
    {
        SqlConnection cnn;
        SqlCommand cmd;
        SqlDataAdapter ad;
        DataSet dt;
        protected void Page_Load(object sender, EventArgs e)
        {
            cnn = new SqlConnection(@"Data Source=DELL-PC\SQLEXPRESS;Initial Catalog=Ecourtservices;User ID=sa;Password=seethal;Pooling=False");
            cnn.Open();

        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            string frm = "";
            frm = TextBox1.Text;
            string to = "";
            to = TextBox2.Text;

            cmd = new SqlCommand("select * from casedetails  where reg_year between'"+ TextBox1.Text+"' AND '" + TextBox2.Text + "'", cnn);
            ad = new SqlDataAdapter(cmd);
            ad.SelectCommand = cmd;
            dt = new DataSet();
            ad.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            GridView1.Visible = true;
        }
    }
}