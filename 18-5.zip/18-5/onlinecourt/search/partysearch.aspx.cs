﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
namespace onlinecourt.search
{
    public partial class partysearch : System.Web.UI.Page
    {
        SqlConnection cnn;
        SqlCommand cmd;
        SqlDataAdapter ad;
        DataSet dt;
        protected void Page_Load(object sender, EventArgs e)
        {
            cnn = new SqlConnection(@"Data Source=DELL-PC\SQLEXPRESS;Initial Catalog=Ecourtservices;User ID=sa;Password=seethal;Pooling=False");
            cnn.Open();

        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            TextBox2.Text = "";
            TextBox1.Text = "";
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            string res = "";
            res = TextBox1.Text;
            string respo = "";
            respo = TextBox2.Text;
            cmd = new SqlCommand("select * from casedetails where reg_year='" + res + "'and respond='" + respo + "'", cnn);
            ad = new SqlDataAdapter(cmd);
            ad.SelectCommand = cmd;
            dt = new DataSet();
            ad.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
    }
}