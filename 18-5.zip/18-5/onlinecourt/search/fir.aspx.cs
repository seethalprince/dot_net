﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
namespace onlinecourt.search
{
    public partial class fir : System.Web.UI.Page
    {
        SqlConnection cnn;
        SqlCommand cmd;
        SqlDataAdapter ad;
        DataSet dt;
        protected void Page_Load(object sender, EventArgs e)
        {
            cnn = new SqlConnection(@"Data Source=DELL-PC\SQLEXPRESS;Initial Catalog=Ecourtservices;User ID=sa;Password=seethal;Pooling=False");
            cnn.Open();


        }

        protected void Button2_Click(object sender, EventArgs e)
        {
           
            DropDownList4.SelectedItem.Text = "";

            TextBox2.Text = "";
            TextBox3.Text = "";
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
        //    string firno = "";
        //    firno = TextBox2.Text;
        //    string reg_year = "";
        //    reg_year = TextBox3.Text;
        //    string police = "";
        //    police = DropDownList4.SelectedItem.Text;
        //     cnn.Open();
        //    cmd.Connection = cnn;
        //    cmd.CommandText = "select * from casedetails where policestation='"+DropDownList4.SelectedItem.Text+"'and firno='"+ firno+"'and reg_year='"+reg_year+"'";
        //    cmd.ExecuteNonQuery();
        //    cnn.Close();
            string policestation = "";
            policestation = DropDownList4.SelectedItem.Text;
            string fir = "";
            fir = TextBox2.Text;
            string year = "";
            year = TextBox3.Text;

            cmd = new SqlCommand("select * from casedetails where policestation='" + policestation + "' and reg_year='" + year + "'and firno='" + fir+ "'", cnn);
            ad = new SqlDataAdapter(cmd);
            ad.SelectCommand = cmd;
            dt = new DataSet();
            ad.Fill(dt);
            DetailsView1.DataSource = dt;
            DetailsView1.DataBind();
        }

       
    }
}