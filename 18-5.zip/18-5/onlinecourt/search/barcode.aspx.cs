﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace onlinecourt.search
{
    public partial class barcode : System.Web.UI.Page
    {
        SqlConnection cnn = new SqlConnection(@"Data Source=DELL-PC\SQLEXPRESS;Initial Catalog=Ecourtservices;User ID=sa;Password=seethal;Pooling=False");

        SqlCommand cmd = new SqlCommand();
       
        
        string status;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            GridView1.Visible = true;
        }

        protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            status = "pending";
        }

        protected void DropDownList4_SelectedIndexChanged(object sender, EventArgs e)
        {
            TextBox1.Text = "hiii";
         //   string barno = null;
         //   string date = null;
         //   string code = null;
         //   cnn.Open();
         //   cmd.Connection = cnn;
         //   cmd.CommandText = "select state_code,bar_no,reg_date from Advocateregister ";
         //SqlDataReader dr=   cmd.ExecuteReader();
         //while (dr.Read())
         //{
         //    barno = dr["bar_no"].ToString();
         //    date = dr["reg_date"].ToString();
         //    code = dr["state_code"].ToString();
           
         //}
         //txtbar.Text = barno;
         //txtstate.Text = code;
         //txtyear.Text = date;

         //   cnn.Close();



        }

        protected void Button7_Click(object sender, EventArgs e)
        {

            SqlDataReader dr;
            string name = DropDownList4.SelectedItem.ToString();
            string barno = null;
            string date = null;
            string code = null;

            

            cnn.Open();
            cmd.Connection = cnn;
            cmd.CommandText = "select name,state_code,bar_no,reg_date from Advocateregister where name='" + name + "'  ";
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                barno = dr["bar_no"].ToString();
                date = dr["reg_date"].ToString();
                code = dr["state_code"].ToString();

            }
            TextBox1.Text =barno;
            TextBox2.Text = date;
            TextBox3.Text = code;

            cnn.Close();

        }

       
    }
}