﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
namespace onlinecourt.search
{
    public partial class Caseno : System.Web.UI.Page
    {
        SqlConnection cnn;
        SqlCommand cmd;
        SqlDataAdapter ad;
        DataSet dt;
        string status;
        protected void Page_Load(object sender, EventArgs e)
        {
            cnn = new SqlConnection(@"Data Source=DELL-PC\SQLEXPRESS;Initial Catalog=Ecourtservices;User ID=sa;Password=seethal;Pooling=False");
            cnn.Open();


        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            GridView2.Visible = true;
            //string cno = "";
            //cno = TextBox1.Text;
            //string year = "";
            //year = TextBox2.Text;
            //string casetype = "";
            //casetype = DropDownList4.SelectedItem.Text;

            //cmd = new SqlCommand("select * from casedetails where case_no='" + cno + "' and reg_year='" + year + "'and c_type='" + casetype + "'", cnn);
            //ad = new SqlDataAdapter(cmd);
            //ad.SelectCommand = cmd;
            //dt = new DataSet();
            //ad.Fill(dt);
            //GridView1.DataSource = dt;
            //GridView1.DataBind();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
            DropDownList4.SelectedItem.Text = "";
            GridView2.Visible = false;
        }

        protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            status = "Pending";

        }
    }
}